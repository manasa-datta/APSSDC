from django.shortcuts import render,redirect
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from onlineform.forms import UsersignupForm
from .forms import TakeadmissionForm
from .models import Admission

@login_required
def home(request):
    return render(request,'onlineform/home.html',{})


def signup(request):
    if request.method=="POST":
        form=UsersignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('signin')
    form=UsersignupForm()
    return render(request,'onlineform/signup.html',{'form':form})


@login_required
def admission(request):
	if(request.method=="POST"):
		a=TakeadmissionForm(request.POST)
		if a.is_valid():
			a.save()
			return redirect('home')
	a=TakeadmissionForm()
	return render(request,'onlineform/admission.html',{'a':a})	



	